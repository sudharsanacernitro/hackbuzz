const cron = require('node-cron');

// Schedule the deletion of the collection to run every minute in Indian Standard Time
cron.schedule('*/1 * * * *', () => {
  // Code to delete the collection goes here
  console.log('Collection deleted at:', new Date());
}, {
  scheduled: true,
  timezone: "Asia/Kolkata" // Indian Standard Time (IST)
});
