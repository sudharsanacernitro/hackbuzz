const accountSid = 'AC233e1551ebf495923c0695db27ea35cc';
const authToken = 'a35eef15632d5bbd9560bbdc40b3574b';
const client = require('twilio')(accountSid, authToken);

client.messages
  .create({
     body: 'Hello from Node.js!',
     from: '9600475008',
     to: '+919345623077'
   })
  .then(message => console.log(message.sid))
  .catch(error => console.error(error));
