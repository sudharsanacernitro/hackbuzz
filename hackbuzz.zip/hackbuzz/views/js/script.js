
 function googleTranslateElementInit() {
    new google.translate.TranslateElement(
        { 
            pageLanguage: 'en', // Set pageLanguage to 'en' for English
            includedLanguages: 'ta,de,en,hi,bn,te,kn', // Adding Indian languages            layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL,
            autoDisplay: false,
            multilanguagePage: true,
            gaTrack: true,
            gaId: 'UA-XXXXX-Y',
            sourceLanguage: 'en', // Set sourceLanguage to 'en' to enforce English
            destinationLanguage: 'ta' // Set destinationLanguage to 'ta' for Tamil
        },
        'google_translate_element'
    );
}

function route(a,arg=null) {
    console.log(a);
    var b = { name: a ,args:arg};
    var mainBody = document.getElementById("main_body");
    mainBody.innerHTML = "";
    while (mainBody.firstChild) {
        mainBody.removeChild(mainBody.firstChild);
    }
    fetch('/sell', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(b)
    })
    .then(response => response.text())
    .then(response => {
        mainBody.innerHTML = response; // Set the response as the innerHTML of main_body
        var script = mainBody.querySelector('script');
        if (script) {
            var existingScript = document.getElementById('injectedscript');
            if (existingScript) {
                existingScript.parentNode.removeChild(existingScript); // Remove existing script with the same ID
            }
            mainBody.removeChild(script);
            append(script.innerHTML, a);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function append(scriptContent, scriptId) {
    var script = document.createElement('script');
    script.setAttribute('id', 'injectedscript');
    script.textContent = scriptContent;
    document.getElementById('main_body').appendChild(script);
}
