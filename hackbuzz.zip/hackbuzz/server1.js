const port = 8001;
const express = require('express');
const bodyParser = require('body-parser'); 
const app = express();
const session = require('express-session');
const redis = require('redis');
const RedisStore = require('connect-redis').default;
const ejs = require('ejs');
const { MongoClient } = require('mongodb');
const {spawn} = require('child_process');
const multer = require('multer');
app.use(express.urlencoded({ extended: true }));
const compression = require('compression');
const { ObjectId } = require('mongodb');
const cron = require('node-cron');
const nodemailer = require('nodemailer');
const filedel = require('./csv');

const redisClient = redis.createClient({
  host: '127.0.0.1',
  port: 6379, });

  redisClient.connect().catch(console.error);
  app.use(session({
    store: new RedisStore({ client: redisClient }),
    secret: 'eren139', 
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, 
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 
    }
  }));

  const uri = 'mongodb://localhost:27017';
  const client = new MongoClient(uri, { useUnifiedTopology: true });
  let db;
  

  client.connect()
    .then(() => {
      db = client.db('farmer');
      console.log('Connected successfully to MongoDB');
      app.listen(port, () => {
        console.log(`App is running on port ${port}`);
      });
    })
    .catch(err => console.error('Error connecting to MongoDB:', err));
  
 


app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/views'));
app.use(compression());
app.use(bodyParser.json());

var user_name,email;

function validate()
{

}
//-----------------------------------login---------------------------------------------------------------------

app.get('/', (req, res) => {
    res.sendFile(__dirname+'/views/index.html'); 
});

app.post('/l',async(req,res)=>{
  console.log(req.body.email+req.body.password);

  
try{
       const collection = db.collection('details'); 
       const result = await collection.findOne({email:req.body.email,psw:req.body.password});
       if(result){

            console.log('found');
            req.session.data={
                   email:req.body.email,
                             };
            res.redirect('/home');
  
                }
      else{
        res.send(`<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login Failed</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background-color: #f4f4f4;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
                .container {
                    text-align: center;
                    background-color: #fff;
                    padding: 20px;
                    border-radius: 5px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                }
                h1 {
                    color: #ff6347;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Invalid Credentials</h1>
                <p>Please check your email and password and try again.</p>
                <a href="/">Back to Login</a>
            </div>
        </body>
        </html>
        `);
      }
 
} 
catch (error) {
  console.error('Error occurred while inserting data:', error);
  res.status(500).send('Internal Server Error');
}

  console.log(req.session.data);
});


//-----------------------------------sign_up-----------------------------------------------------------------

app.get('/sign_up',(req,res)=>{
  res.sendFile(__dirname+'/views/sign_up.html');
});

app.post('/sign_up_action',async(req,res)=>{
  console.log(req.body);
try{
             const collection = db.collection('details'); 
             const result = await collection.insertOne(req.body);
             console.log('Document inserted successfully:', result.insertedId);

              res.redirect('/');
} 
catch (error) {
             console.error('Error occurred while inserting data:', error);
             res.status(500).send('Internal Server Error');
}
 
});


//===================================[ home_page ]===========================================================
var result;
var search_results;
app.get('/home',async(req,res)=>{
  
  const data = "hai";
 
  
try{
  const collection = db.collection('sell_details'); 
  const result1 = await collection.find({}).toArray();
  //console.log(result1);
  result=result1;
  res.render(__dirname+'/views/template',{result});

} 
catch (error) {
  console.error('Error occurred while inserting data:', error);
  res.status(500).send('Internal Server Error');
}

});

//====================================[ main-render ]======================================================================================

app.post('/sell',async(req,res)=>{
  console.log(req.body.name+'\n');
  //console.log(req.body.args);
  var id;
  switch(req.body.name)
  {
    case '/search':

    try{
        const collection = db.collection('sell_details'); 
        const result1 = await collection.find({}).toArray();
        //console.log(result1);
        res.render('search',{result1});
      } 
    catch (error) {
        console.error('Error occurred while inserting data:', error);
        res.status(500).send('Internal Server Error');
      } 
      break;

    case '/sell_product':
      res.render('sell');
      break;

    case '/home':
      //console.log(result);
      if(req.body.args!=null)
      {
        console.log("home page with Arguments:",req.body.args);
        try{
          const collection = db.collection('sell_details'); 
          const result = await collection.find({'name-product':req.body.args}).toArray();
          //console.log(result1);
          res.render('main',{result});
        } 
      catch (error) {
          console.error('Error occurred while inserting data:', error);
          res.status(500).send('Internal Server Error');
        } 
      }
      else{
        try{
          const collection = db.collection('sell_details'); 
          const result = await collection.find({}).toArray();
          //console.log(result1);
          res.render('main',{result});
        } 
      catch (error) {
          console.error('Error occurred while inserting data:', error);
          res.status(500).send('Internal Server Error');
        } 

      }
      //res.render('main',{result});
      break;
   

    case '/sub-sell':
            console.log(req.body.args);
          try{
              const collection = db.collection('sell_details'); 
              var objectId = new ObjectId(req.body.args); // Assuming you have the ObjectId
              const result1 = await collection.findOne({_id:objectId});
              console.log(result1);
              res.render('main_post',{result1});
            } 
          catch (error) {
              console.error('Error occurred while inserting data:', error);
              res.status(500).send('Internal Server Error');
            } 
          break;

    case '/bid':
             id=req.body.args.id;
            try{
              const collection = db.collection(req.body.args.id); 
              const result1 = await collection.find({}).toArray();
              console.log(result1);
              
              var deadline=req.body.args.param;
              res.render('bid',{result1,deadline,id});
            } 
          catch (error) {
              console.error('Error occurred while inserting data:', error);
              res.status(500).send('Internal Server Error');
            } 
           console.log("Arguments:",req.body.args);
           break;
    case '/profile':
      try{
        const collection1 = db.collection('details'); 
        const result1 = await collection1.find({email:req.session.data.email}).toArray();
        const collection2 = db.collection('sell_details'); 
        const result2 = await collection2.find({email:req.session.data.email}).toArray();
        console.log(result1);
        
        res.render('profile',{result1,result2});
      } 
    catch (error) {
        console.error('Error occurred while inserting data:', error);
        res.status(500).send('Internal Server Error');
      } 
      //console.log(req.session.data.email);
          //res.render('profile');
  }
  console.log("\n==========================================================================\n");

});
//====================================[ sell-backend ]========================================================================

var a;
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
      cb(null, __dirname+'/public/sell/');
  },
  filename: function (req, file, cb) {
    const currentDate = new Date();
    const time = currentDate.toLocaleDateString().replace(/\//g, '') + currentDate.toLocaleTimeString('en-US', { hour12: false }).replace(/:/g, '');
    a=req.body.email.split('@')[0]+time+'.png';
      cb(null, a);
  }
});
const upload = multer({ storage: storage });

app.post('/sell_data',upload.single('image'),async(req,res)=>{
  var sell_data=(req.body);
  sell_data['img']=a;
  console.log(sell_data);

  try{
    const collection = db.collection('sell_details'); 
    const result = await collection.insertOne(sell_data);
    console.log('Document inserted successfully and collection created',result.insertedId);
    await db.createCollection(result.insertedId.toString());
                
            const desiredTime = new Date(sell_data['date']+'T'+sell_data['time']);

            const minute = desiredTime.getMinutes();
            const hour = desiredTime.getHours();
            const dayOfMonth = desiredTime.getDate();
            const month = desiredTime.getMonth() + 1; 
            const dayOfWeek = desiredTime.getDay(); 

            cron.schedule(`${minute} ${hour} ${dayOfMonth} ${month} ${dayOfWeek}`, async() => {
              console.log('Collection deleted at:', desiredTime);
                    //To convert db to csv and send mail to clients
                   try {
                      var v=filedel.dbdel(result.insertedId.toString());
                      await sendmail(sell_data['email'], v);
                        }
                    catch (error) {
                      console.error('Error occurred while sending email:', error);
                        }

            }, {
              scheduled: true,
              timezone: "Asia/Kolkata" 
            });


    msg="successfully uploaded";
    res.render('success',{msg});
      } 
catch (error) {
    console.error('Error occurred while inserting data:', error);
    res.status(500).send('Internal Server Error');
}

});


//funciton to send mail
async function sendmail(email,msg)
{
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'sudharsanr.22cse@kongu.edu',
        pass: 'pcmb akly xcsm yvvm ',
    },
    secure: true,
    port: 465,
});

const mailOptions = {
    from: 'sudharsanr.22cse@kongu.edu',
    to: email, // Use the provided user email
    subject: 'UZHAVAN',
    text: `Your csv file is at - http:localhost:8001${msg}`,
};

 transporter.sendMail(mailOptions);
}

//================================================[ bid-backend ]==================================================
app.post('/bid_backend',async(req,res)=>{

  var msg="successful";
  console.log("Seperate route -'/bid_backend'");
  //console.log(req.body);
  var id=req.body.id;
  var values=req.body;
  delete values.id;
  console.log(values);
  
  try{
    const collection = db.collection(id); 
    const result = await collection.insertOne(values);
    console.log('Document inserted successfully and collection created',result.insertedId);
    msg="successfully uploaded";
    res.render('success',{msg});
      } 
catch (error) {
    console.error('Error occurred while inserting data:', error);
    res.status(500).send('Internal Server Error');
}

});