function dbdel(a){

const { MongoClient } = require('mongodb');
const { createObjectCsvWriter } = require('csv-writer');
const { ObjectId } = require('mongodb');
var csvpath;

// Connection URI
const uri = 'mongodb://localhost:27017';

// Database Name
const dbName = 'farmer';

// Collection Name
const collectionName = a;

// Create a new MongoClient
const client = new MongoClient(uri, { useUnifiedTopology: true });

async function main() {
  try {
    // Connect the client to the server
    await client.connect();

    // Connect to the database
    const db = client.db("farmer");

    // Get the collection
    var collection = db.collection(a);

    // Fetch all documents from the collection
    const cursor = collection.find({});
    const documents = await cursor.toArray();
  if(documents.length>=1)
  {
         // Define CSV headers based on keys of the first document
    const headers = Object.keys(documents[0]);

    // Create CSV writer
    const csvWriter = createObjectCsvWriter({
      path: './public/csv/'+a+'.csv',
      header: headers.map(header => ({ id: header, title: header }))
    });

    // Write data to CSV file
    await csvWriter.writeRecords(documents);

    console.log('CSV file has been created successfully.');
  

  }
  else{
    csvpath="No entries are done";
  }
  await collection.drop();
  collection=db.collection('sell_details');
  var objectId = new ObjectId(a); // Assuming you have the ObjectId

  await collection.deleteMany({_id:objectId});

  } catch (err) {
    console.error('Error:', err);
  } finally {
    // Close the client
    await client.close();
  }
}

main().catch(console.error);
csvpath="/csv/"+a+".csv";
return csvpath;
}


module.exports = {
  dbdel: dbdel
};